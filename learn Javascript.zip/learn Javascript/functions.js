
// FUNCTION DECLARATION VS EXPRESSIONS
// so basically we have two methods to decalare a function in javascript

// FUNTION DECLARATION

function walk(){
    console.log('walk');
}


// FUNCTION EXPRESSION
// here in the below code we can call it anonymous function we didn't give the function a name

const run = function(){
    console.log('run');
};
let move = run;
run();
move();



// HOISTING


// SO IF SOMEONE ASKED U IN UR JOB INTERVIEW WHAT IS HOISTING

// so basically hoisting is the process of moving function declarations to the top of the file 
// And it is done automatically by the javascript engine that is executing this code



// ARGUMENTS


// 1 + undefined (result =) NaN 
// the same happens when we don't pass an argument


function sum(){
    let total = 0;

    // as we know that forof loop is used on arrays only but that object has a iterator 
    // forof loop deals with the iterator 
    for (let value of arguments)
    total += value;
    return total;
}

console.log(sum(1,2,3,4,5,10));




// THE REST OPERATOR

// if we have vary number of parameters then we can use the rest operator

function sum(discount,...prices)
// so the above code is the rest operator 
// don't compare it with spread operator which is used in array
// in the above code we have a function and parameters
{
    const total = prices.reduce((a,b) => a + b);
    return total * (1 - discount);
}
console.log(sum(0.1,20,30,1));




// DEFAULT PARAMETERS

function interest(principal,rate = 3.5,years){
    return principal * rate / 100 * years;
}     

// in the below code we have written undefined to the rate 
// which is known as the default value

console.log(interest(1000,undefined,5));




// GETTERS AND SETTERS



const person = {
    firstName:'Mansoor',
    lastName:'ahmad',

    // we use getters to access the properties of an object

    get fullName()
    {
        return `${person.firstName} ${person.lastName}`
    },


    // and we use setters to change them or mutate them

    set fullName(value) {
        const parts = value.split(' ');
        this.firstName = parts[0];
        this.lastName = parts[1];
    }
};
person.fullName = 'Mansoor300';

console.log(person);





// TRY AND CATCH
const person = {
    firstName: 'Mansoor',
    lastName:'Ahmad',

set fullName(value){
    if (typeof value !== 'string')

    // in the below code this is how we throw an exeption
    throw new Error('Value is not string.');

    const parts = value.split(' ');
    if (parts.lenght !== 2)
    throw new Error('Enter a first and last name.');


    this.firstName = parts[0];
    this.lastName = parts[1];
  }
};

// so these try blocks can throw an exception
try{
    person.fullName = '';
}
catch (e){
    alert(e);
}



// LOCAL VS GLOBAL SCOPE OR CONSTANTS


// this const have global scope or constants it is accessible everywhere globally
const color = 'red';

function start(){
    const message = 'hi';

    // the below is a local scope or local constant in a function
    const color = 'blue';
    console.log(color);
}

function stop(){
    const message = 'bye';
}

start();




// LET VS VAR

// var creates function scoped variables
// IN ES6 (ES2015): let and const creates block scoped variables

// when we declare variabel with var its scope is not limited to the block in which its defined
// its limited to the function in which its defined
var color = 'red';
let age = 30;

function sayHi(){
    console.log('hello');
}





// THIS KEYWORD

// (This) reference to the object that is executing the current function


// so if that function is part of an object we call that method 
// Method reference to object itself



// if it is a regular function means it is not part of an object
// Function reference to global objects (which means window objects in browsers and global in Node)



const video = {
    title: 'a',
    tags: ['a','b','c'],
    showtags(){
        this.tags.forEach(function(tags)
        {
            console.log(this ,tags);
        }, this );
    }
};

video.showtags();


// CHANGING THE VALUE OF THIS


// there are 3 ways to change this

// first solution is 

const self = this;

// second solution

// .bind(this);


// third solution is the arrow function 


const video = {
    title: 'a',
    tags: ['a','b','c'],
    showtags(){
        this.tags.forEach(tag => {
            console.log(this.title ,tag);
        });
    }
};

video.showtags();