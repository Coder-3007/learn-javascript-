//OBJECTS are collection of key value pairs


//object  oriented  programming(OOP)
// It is a style a programming where we see a function as an object that to each other to perform some action 
const circle = {
    radius: 1,
    location: {
        x: 1,
        y: 1
    },
    isVisible: true,
    draw: function() {
        console.log('draw');
    }
};

circle.draw();

// here we have some object and in object we have function which we call the whole process a METHOD.

//FACTORY FUNCTION

//As image we are performing differnt objects such as the circle object so for this we use factory function

//As in factory fuction we create different objects

// so the beauty of factory function is that we can define our logic in one place

// createCirle is known as Camel notation (oneTwoThreeFour) the first word of the letter is smaller and the second firstword of the letter is uppercase

function createCircle(radius) {
    return {
        radius,
        draw() {
            console.log('draw');
        }
    };
}
const circle1 = createCircle(1);
console.log(circle1);



//CONSTRUCTOR FUNCTION

//For more appropiate coding we use Pascal Notation (OneTwoThreeFour) in constructor function for a cleaner code

//In javasript we have keyword called this(which refers to the object that is executing this piece of code)


function Circle(radius) {
    this.radius = radius;
    this.draw = function() {
        console.log('draw');
    }
}

const circle = new Circle(1);

//As we know that javascript is a dynamic language where we can change the code,So OBJECTS ARE ALSO DYNAMIC IN NATURE and we can change the code and values of it or even delete it

const circel = {
    radius: 1
};

circle = {};

circle.color = 'yellow';
circle.draw = function() {}

// As I told u we can delete it to so 

delete circle.color;
delete circle.draw;

console.log(circle);




//Every object has a CONSTRUCTOR PROPERTY and the refernce is the function that is used to create that object.



//In javascript FUCTIONS ARE OBJECTS.





//Value Types(also called PRIMITIVES) VS Reference Types (also called OBJECTS).

//PRIMITIVES are copied by their VALUE.

//OBJECTS are copied by their REFERENCE.


let obj = { value: 10 };

function increase(obj) {
    obj.value++;
}
increase(obj);
console.log(obj);

//object is not iterable so we cannot use for of in it.and arrays are  



// Enumerating properties of an object
// we r using for iterating over properties

const circle  = {
    radius:1,
    draw(){
        console.log('draw');
    }
};

for (let key in circle)
console.log(key,circle[key]);
// we r using bracket notation for this

for(let key of Object.keys(circle))
console.log(key);

for(let key of Object.entries(circle))
console.log(entry);

if ('color' in circle ) 
console.log('yes');


// cloning an object

// there are three methods to clone an object


const circle  = {
    radius:1,
    draw(){
        console.log('draw');
    }
};
// 1

const another = {};
for (let key in circle)
another[key]=circle [key];

// 2

const another = Object.assign({}, circle);

// 3

const another ={ ...circle};


console.log(another);


// as javascript engine is garbage collector job is to find the variables and constants that are no longer used and then deallocate the memory that was allocated to them earlier

// string object 


// template literals object

const another=

`hi mansoor,

thank u.
regards,
mansoor`;


// date object