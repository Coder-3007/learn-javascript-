// ADDING ELEMENTS

const numbers = [3,4];

// At End

numbers.push(5,6);

// At Beginning

numbers.unshift(1,2);


// At Middle

// there is a trick in splice method u must see the lectures again

numbers.splice(2,0,'a','b');

console.log(numbers);



// FINDING ELEMENTS (PRIMITIVES)

const numbers = [1,2,3,1,4];

// these methods will return the index of these elements in array

// the type of these elements matters if we pass 1,as a string here so we get -1 because we dont have 1 as a string in above array 

console.log(numbers.indexOf(1,2));

console.log(numbers.lastIndexOf(1));

console.log(numbers.indexOf(1) !== -1);

// new method of above one is  

console.log(numbers.includes(1));


// FINDING ELEMENTS(REFERENCE TYPES or OBJECTS)

// this code is for finding the elements  in an array

const courses = [
    { id: 1, name: 'a'},
    { id: 2, name: 'b'},
];

const course = courses.find(function(course){
 return course.name === 'a';
});

// the function is called back for finding the element in the array
// this function is a predicate function

console.log(course);


// ARROW FUNCTION 
// in es6 thier is shorter and cleaner method by using arrow function instead of predicate function



const courses = [
    { id: 1, name: 'a'},
    { id: 2, name: 'b'},
];

const course = courses.find(course  => course.name === 'a');


console.log(course);

// less noise in the code



// REMOVING ELEMENTS IN AN ARRAY


const numbers = [1,2,3,4];

// At End

const last = numbers.pop();

// At Beginning

const first = numbers.shift();


// At Middle

numbers.splice(2,1);

console.log(numbers);




// EMPTYING AN ARRAY


// So for emptying an array we have 4 methods 

// Method 1

numbers = [];

// Method 2  as this is the easy and recommended method

numbers.length = 0;

// Method 3

numbers.splice(0, numbers.length);

// Method 4

while (numbers.length > 0)
numbers.pop();

console.log(numbers);
console.log(another);



// COMBINING AND SLICING AN ARRAY 


const first = [1,2,3];
const second = [4,5,6];


// this is for combining the first and second array
const combined = first.concat(second);
console.log(combined);

// this is to slice an array into two parts
const slice = combined.slice(2);
console.log(slice);

// As for objects in an array

const first = [{ id: 1 }];
const second = [4,5,6];

// we r dealing with reference type this object is copied to its reference type and the same principle is applied to the slice method
const combined = first.concat(second);
first[0].id = 10;
console.log(combined);


const slice = combined.slice(2);
console.log(slice);



// so we have another array such lasw slice method which we call
// THE SPREAD OPERATOR

const first = [1,2,3];
const second = [4,5,6];


// const combined = first.concat(second);
const combined = [...first,'a',...second,'b'];

// const copy = combined.slice();
const copy = [...combined];


// ITERATING AN ARRAY BY DIFFERENT WAYS

const numbers = [1,,2,3];

for(let numbers of numbers)
console.log(numbers);

// arrow function in it
numbers.forEach((number, index) => console.log(index, numbers));


// JOINING AN ARRAY

const numbers =[1,2,3];
// for joining an array
const joined = numbers.join(',');
console.log(joined);

// FOR SPLITTING AN ARRAY

const message = 'This my first message';
const parts = message.split('');
console.log(parts);

// FOR COMBINING THE ABOVE MESSAGE OR JOINING THE MESSAGE
// IT IS USE IN URL SLUG
const combined = parts.join('-');
console.log(combined);



// SORTING AN ARRAY

const courses = [ 

    // these are objects
    { id:1, name: 'Node'},
    { id:2, name: 'java'},
];

courses.sort(function(a,b)
{
    // a < b => -1
    // a > b => 1
    // a === b => 0


    if (nameA < nameB) return -1;
    if (nameA > nameB) return 1;
    return 0;
});

// ANOTHER EXAMPLE

const courses = [ 

    // these are objects
    { id:1, name: 'Node'},
    { id:2, name: 'java'},
];

courses.sort(function(a,b)
{
    // a < b => -1
    // a > b => 1
    // a === b => 0

    const nameA = a.name.toLocaleLowerCase();
    const nameB = b.name.toLocaleLowerCase();

    if (nameA < nameB) return -1;
    if (nameA > nameB) return 1;
    return 0;
});

// FOR REVERSE WE USE 
number.reverse();





// TESTING THE ELEMENT IN THE ARRAY



// every() method

const number = [1,-1,2,3];

const allPositve = numbers.every(function(value){
    return value >= 0;
});

console.log(allPositve);

// some() method

const number = [1,-1,2,3];
const atLeastOnePositve = numbers.some(function(value){
    return value >= 0;
});

console.log(allPositve);



// FILTERING AN ARRAY 
// IT IS USED TO GET BACK OUR NUMBERS


const numbers = [1,-1,2,3];

const filtered = numbers.filter(n => n >= 0);
console.log(filtered);




// MAPPING AN ARRAY
// we can map it to a string and also to an object

const numbers = [1,-1,2,3];

const items = numbers

// the below method is chaining
// the below code is giving us an array
.filter(n => n >= 0 )
.map(n => ({ value: n}))

// the below code is giving us an object in an array
.filter(obj => obj.value > 1)
.map(obj => obj.value);

console.log(items);





// REDUCING AN ARRAY
// this is used to calculate the sum in this array

const numbers = [1,-1,2,3]

// what happened in the code is explained below in the comment section

// a = o, c = 1 => a = 1
// a = 1, c = -1 => a = 0
// a = o, c = 2 => a = 2
// a = 2, c = 3 => a = 5

// a = 1, c = -1 => a = 0
// a = o, c = 2 => a = 2
// a = 2, c = 3 => a = 5


const sum = numbers.reduce(
    (accumulator, currentValue) => accumulator + currentValue
);

let sum = 0;
for (let n of numbers)
sum += n;

console.log(sum);