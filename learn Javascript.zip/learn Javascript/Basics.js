// VARIABLES:


let name = 'Mansoor';
console.log(name);

// Cannot be a reseved keyword
// Should be meaningfull
// Cannot start with a number => (1 name)
// Cannot contain a space or hypen(-)
// Are case-sensitive



// CONSTANTS:

let firstName = 'Mansoor';

// The above is the right way 
let LastName = 'Ahmad'; // => this is the wrong way of propessional coding


let interestRate = 0.3;
interestRate = 1;
console.log(interestRate); // So the value of variable is changable


const interestrate = 0.2;
Interestrate = 2;
console.log(interestrate);

// But the value of constants cannot be change  => Keep that in mind



// PRIMITIVE / VALUE TYPES:

// 1)String:

let name = 'Mansoor'; // We call it String literal


// 2)Number:

let age = 23; // We call it Number literal


// 3)Boolean:

let isApproved = true; // We call it Boolean literal

let isApproved = false;
// For Example:
// if the order is approved then, it need to be shipped so the value of boolean is true or false 
// And both True and False are reserved keywords so they cannot be Variables


// 4)Undefined:

let firstName = undefined;


// 5)Null:

// let lastName = null; we use null if we want expicitly clear the vale of variable

// For Example:
let selectedColor = null;

// If the user want to select another color then we reassign this variable to a color like red
let selectedColor = 'red';
// So we use null if we want to clear the value of a variable



// DYNAMIC TYPING:

// As we know that JavaScript is Dynamic Language(Dynamically-typed) not a Static Language(Statically-typed) where the type of variable can change at runtime


// REFERNCE TYPES: 

// 1) Object

// An object in programming languags is an object in real life
// So when we are dealing with mutiple variable we put it inside a object

// FOR EXAMPLE:

let name = 'Mansoor';
let age = 23;

// So let put it object

// {}; > this is object literal  iinside the curly braces we have one or more key value pairs
// So the keys are what we call the properties of this object 

let person = {
    name: 'Mansoor',
    age: 30
};

//So if we want to change the name of this person we have two properties

// 1) DOT NOTATION:

person.name = 'Ahmad'
    // For we change the consolelog property to console.log(person.name)

// 2) BRACKET NOTATION:

person['name'] = 'Mansoor';

// We add console log by two same as the dot notation or console.log(person[name])

console.log(person.name);

// As we see dot notation is easy to use so it is better and shorter for a pro programmer


// We can also use bractet notation in a dynamic way by changing the variable in runtime
// FOR EXAMPLE:

let selection = 'name';
person[selection] = 'Mansoor';


// 2) Array

// An array is DataStructure that we use to represent a list of items
// [] These brackets we array literals and now they are empty array

let selectedColors = ['red', 'blue'];

// And array is also an object so where we change the variables at runtime dynaically

selectedColors[2] = 'green';
// So the length is dynamic it can change 

//And the type of object in this array is dynamic we can also change it to number and to other reference types to
selectedColors[2] = 1;

//So the object in an array and the size of the array is dynamic 

//An array is an object so we change its variable by dot notation

console.log(selectedColors.length);

// it also has many properties such as an object > length, fill,foreach etc

console.log(selectedColors);


// 3) Function

// Functions are one of the fundamental building blocks in javascript
//it is basically a set of statements that perform a task or calculates a value

// () this pararnthsis is for declaring a function
// as in {}(curly braces) we refers to the body of a function where we apply some logic by a statement for our application


function greet() {
    console.log('Hello World');
} // so at the end of a function we are not adding  semi column(;) in because we declaring a function not a variable in it

greet();

// As for the(;) it after greet is to declare it that is a statement

// So our functions have inputs and thats how they behaves
// So for the name of a person

function greet(name) {
    console.log('Hello' + name);
    // greet(name) > where name is variable here and we refer this to a PARAMETER which is meaningful inside of a function
    // + is for to concatinate two strings
}
greet('john');
//here john is an ARGUMENT to the greet() function and name is the PARAMETER of the greet() function

// as  ARGUMENT an actual value we supply for PARAMETER


// so we can reuse this function with different input

function greet(name) {
    console.log('Hello' + name);
}
greet('John');
greet('Mary')

// and also functions have seperate parameters

function greet(name, lastName) {
    console.log('Hello' + name + '' + lastName);
}
greet('John', 'Snow');



// TYPES OF Function:

// Performing a task

function greet(name, lastName) {
    console.log('Hello' + name + '' + lastName);
}

//Calculating a value
function square(number) {
    return number * number;
}

console.log(square(2));