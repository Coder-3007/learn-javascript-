//In javascript we two type of conditional statements If else and switch..case

//If else

if (condition) {
    statement
} else if (anotherCondition) {
    statement
} else if (anotherCondition) {
    statement
} else

    statement


//Hour
//If hour is between 6am and 12pm:Good morning!
//If it is betweeen 12pm and 6pm: Good afternoon!
//Otherwise:Good evening!


let hour = 10;

if (hour >= 6 && hour < 12) {
    console.log('Good mornig!');
} else if (hour >= 12 && hour < 18) {
    console.log('Good afternoon!');
} else
    console.log('Good evening!')


//Switch case

let role = 'guest';

switch (role) {

    case 'guest':
        console.log('Guest user');
        break;

    case 'moderator':
        console.log('Moderator user');
        break;

    default:
        console.log('Unknown user')
}

//This program in if else case

if (role === 'guest') console.log('Guest');
else if (role === 'moderator') console.log('Moderator');
else console.log('Unknown user');

//As we know from the above programs that ifelse case is shorter than switch case

// LOOPS

//FOR LOOP
//WHILE LOOP
//DO WHILE LOOP
//FOR IN LOOP
//FOR OF LOOP


//FOR LOOP

for (intial experation; condition; increment expression) {
    statement
}

for (let i = 0; i < 5; i++) {
    console.log('Hello World');
}
// OR
for (let i = 1; i <= 5; i++) {
    if (i % 2 != 0) console.log(i);
}
// OR
for (let i = 5; i >= 1; i--) {
    if (i % 2 != 0) console.log(i);
}

//WHILE LOOP

let i = 0;

while (condition) {
    statement
    increment
}

let i = 0;

while (i <= 5) {
    if (i % 2 != 0) console.log(i);
    i++;
}

//DO WHILE LOOP

let i = 0;

do {
    statements
} while (condition);
//do while loops are always executed at once if the condition evaluates to false

let i = 0;
do {
    if (i % 2 != 0) console.log(i);
    i++;
}
while (i <= 5)

//INFINITE LOOP

let i = 0;
while (i > 5) {
    console.log(i);
    // i++:


    // so this infinite loop will run forever because we donot put increment declration

}

//FOR IN LOOP

//we use to iterate an object or element in an array

// object with two properties
const person = {
    name: 'Mansoor',
    age: 23
};

for (let key in person)
    console.log(key, person[key]);

// so there r two ways to access the properties of an object

//dot notation
// person.name

//bracket notation
// person['name ']

// how to iterate an array

const colors = ['red', 'green', 'blue'];

for (let index in colors)

// for  numbers in an array
    console.log(index);

// and for numbers and elements in an array

console.log(index, colors[index]);



//FOR OF LOOP

//We use for of loop for elements or items of an array

const colors = ['red', 'green', 'blue'];
for (let color of colors)
    console.log(color);

//we have learned all the loops here we have two keywords
// which can change how the loop behaves
//Break and Continue

let i = 0;
while (i <= 10) {
    console.log(i);
    i++;
}

//for  BREAK keyword

let i = 0;
while (i <= 10) {
    if (i === 5) break;


    console.log(i);
    i++;
}

//for CONTINUE keywordlet i = 0;
while (i <= 10) {

    if (i % 2 === 0) {
        i++;
        continue;
    }

    console.log(i);
    i++;
}